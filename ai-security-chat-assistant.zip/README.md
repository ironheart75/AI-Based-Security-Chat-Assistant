# Sentinel — AI-based defensive security assistant

A complete Next.js App Router workspace for explaining alerts and logs with source-grounded guidance. PostgreSQL and Drizzle persist security events, vector-embedded reference documents, multi-turn investigations, and audit records. An optional Python/FastAPI service handles vector similarity retrieval.

## Included workflows
- Overview with telemetry counts, prioritized sample alerts, knowledge pipeline, and recent audit activity.
- Advisory security chat, sanitized log attachments, relevant alert context, numbered source citations, follow-up questions, persisted history, and JSON export.
- Alert search, severity/status filters, raw log download, analyst-reviewed resolution, and investigation handoff.
- Knowledge ingestion (playbooks, policies, runbooks, documentation), immediate embedding/indexing, content inspection, and export.
- Search across alerts, knowledge, and investigations; audit search and export; notification center; citation preferences.

## Run
1. Install Node dependencies using `npm install`.
2. Configure `DATABASE_URL` for PostgreSQL.
3. Apply the schema with `npx drizzle-kit push`.
4. Run `npm run dev`, or `npm run build` followed by your production process manager.
5. Open `/`. The first workspace request idempotently seeds six sample alerts and six defensive reference documents. `/api/health` checks the database.

## Retrieval and grounding
The default embedding is an explicitly labeled 256-dimensional feature-hash **lexical** vector, with normalization and a small security terminology alias map. It is not a pretrained semantic embedding model. PostgreSQL JSONB stores the vectors; application-side cosine similarity provides exact retrieval at demo scale. This is not a pgvector/HNSW deployment. For larger deployments, migrate to a dedicated vector index and use an approved semantic embedding model.

Chat retrieves the top three references above a relevance threshold, correlates matching workspace alerts, and builds a defensive-only prompt. Local mode composes reference-based guidance without a live LLM. Missing evidence leads to an explicit uncertainty response. The approved-model path checks that output contains valid source reference numbers; this is **citation syntax validation, not entailment or truth verification**. All conclusions still require analyst review.

## Optional approved LLM
Set both server-only environment variables:
- `OPENAI_API_KEY`: API credential from your approved provider account.
- `APPROVED_LLM_MODEL`: an organization-approved model ID supporting the OpenAI Responses API.

Requests use `https://api.openai.com/v1/responses`, `store: false`, a defensive system instruction, and redacted question/history/reference context. If the provider times out, errors, or fails reference checks, a visibly labeled local fallback is returned. Keys are never exposed to the browser. No model call occurs without both variables. API configuration does not by itself establish organizational approval; your administrator is responsible for model and data-sharing approval.

**Data boundary:** local-mode data stays in PostgreSQL/the app. Approved LLM mode sends the redacted question, recent conversation, relevant alert context, and retrieved reference excerpts to OpenAI. Pattern-based secret redaction is not comprehensive DLP. Never upload sensitive production content to this shared demo.

## Optional Python / FastAPI engine
The working preview does not require a separately managed Python process. To deploy the optional retrieval worker:
1. Install `services/security-engine/requirements.txt` into a Python 3.10+ environment.
2. Set a strong `SECURITY_ENGINE_TOKEN` in both the worker and the Next.js server.
3. Start the worker from its directory with `uvicorn main:app --host 127.0.0.1 --port 8000` (bind/proxy appropriately for your private production network).
4. Set `SECURITY_ENGINE_URL` on the Next.js server to the trusted worker base URL.

The worker exposes `/health`, authenticated `/embed`, and authenticated `/retrieve`. Pydantic validates request limits and vector dimensions. Next.js loads vectors through Drizzle and calls the worker; the worker has no direct database credentials. Python and TypeScript share the exact same lexical embedding space, so timeout fallback preserves retrieval compatibility. Do not expose the worker publicly without TLS and network controls.

## Safety and audit limitations
- Advisory only: no command execution, no automated containment, no offensive tooling.
- Original inputs are redacted before persistence and model requests for common secret patterns. This is best-effort, not a guarantee.
- Sample alerts are clearly identified as demo telemetry; the UI does not connect to AWS or Microsoft Defender.
- Every completed investigation saves question, response, citations, mode, and an audit event transactionally. Invalid payloads are rejected. Source ingestion is also transactionally recorded.
- Guardrails combine defensive prompting, limited request-pattern screening, reference checking, and human review. They are not a comprehensive security boundary.
- The demo has **no authentication or tenant isolation**. The Jamie Davis profile is illustrative. Do not deploy to untrusted users with real telemetry until you add SSO/RBAC, tenant-scoped authorization, CSRF/rate limits, encrypted secret handling, retention controls, immutable audit storage, and monitoring.

## Validation
Run `npx next typegen`, `npm exec tsc -- --noEmit --pretty false`, and `npm run build`. Browser smoke tests can use the installed Playwright package. Python retrieval is deterministic and can be tested with the FastAPI test client.
