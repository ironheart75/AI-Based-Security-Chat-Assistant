"""Optional FastAPI vector retrieval worker. PostgreSQL access remains in Next.js/Drizzle."""
import hmac
import math
import os
import re
from fastapi import Depends, FastAPI, Header, HTTPException
from pydantic import BaseModel, Field

app = FastAPI(title="Sentinel Security Retrieval Engine", version="1.0.0")
ALIASES = {"authentication": "login", "signin": "login", "ssh": "login", "brute": "login", "credentials": "login", "outbound": "network", "traffic": "network", "powershell": "execution", "script": "execution", "malware": "execution", "privilege": "permission", "iam": "permission", "escalation": "permission", "dns": "network"}
STOP_WORDS = {"the", "and", "for", "that", "this", "with", "from", "what", "explain"}


def authorize(authorization: str = Header(default="")) -> None:
    token = os.getenv("SECURITY_ENGINE_TOKEN")
    if not token:
        raise HTTPException(status_code=503, detail="Configure SECURITY_ENGINE_TOKEN before serving requests")
    if not hmac.compare_digest(authorization, f"Bearer {token}"):
        raise HTTPException(status_code=401, detail="Unauthorized")


def embed(text: str) -> list[float]:
    """256-dimension feature-hash lexical embedding; identical to the TypeScript fallback."""
    vector = [0.0] * 256
    for token in re.findall(r"[a-z0-9]+", text.lower()):
        if len(token) < 3 or token in STOP_WORDS:
            continue
        token = ALIASES.get(token, token)
        value = 2166136261
        for char in token:
            value = ((value ^ ord(char)) * 16777619) & 0xFFFFFFFF
        vector[value % 256] += 1
    norm = math.sqrt(sum(v * v for v in vector)) or 1
    return [v / norm for v in vector]


class EmbedRequest(BaseModel):
    text: str = Field(min_length=1, max_length=50000)


class VectorDocument(BaseModel):
    id: str = Field(min_length=1, max_length=200)
    embedding: list[float] = Field(min_length=256, max_length=256)


class RetrieveRequest(BaseModel):
    query: str = Field(min_length=1, max_length=50000)
    documents: list[VectorDocument] = Field(max_length=1000)
    limit: int = Field(default=3, ge=1, le=10)


@app.get("/health")
def health():
    return {"status": "ok", "embedding": "lexical-feature-hash-v1", "dimensions": 256}


@app.post("/embed", dependencies=[Depends(authorize)])
def create_embedding(body: EmbedRequest):
    return {"embedding": embed(body.text), "model": "lexical-feature-hash-v1"}


@app.post("/retrieve", dependencies=[Depends(authorize)])
def retrieve(body: RetrieveRequest):
    query = embed(body.query)
    results = []
    for document in body.documents:
        if not all(math.isfinite(value) for value in document.embedding):
            raise HTTPException(status_code=422, detail="Non-finite vector values are not allowed")
        score = sum(a * b for a, b in zip(query, document.embedding))
        if score > 0.09:
            results.append({"id": document.id, "score": score})
    return {"results": sorted(results, key=lambda item: item["score"], reverse=True)[:body.limit], "engine": "fastapi-lexical-v1"}
