import { db } from "@/db";
import { alerts, sources, auditEvents } from "@/db/schema";
import { embed, seedAlerts, seedSources } from "@/lib/security";
let initialization: Promise<void> | undefined;
export async function initializeWorkspace() {
  if (!initialization) initialization = (async () => {
    await db.insert(sources).values(seedSources.map(source => ({ ...source, embedding: embed(source.title + " " + source.content) }))).onConflictDoNothing();
    await db.insert(alerts).values(seedAlerts.map(({ minutes, ...alert }) => ({ ...alert, createdAt: new Date(Date.now() - minutes * 60000) }))).onConflictDoNothing();
    await db.insert(auditEvents).values([
      { id: "audit-initial-1", action: "Knowledge base synchronized", detail: "6 approved reference documents indexed with local lexical embeddings.", kind: "source", createdAt: new Date(Date.now() - 18 * 60000) },
      { id: "audit-initial-2", action: "Security telemetry connected", detail: "6 sample alerts imported. This is a demonstration workspace, not a live security feed.", kind: "system", createdAt: new Date(Date.now() - 35 * 60000) },
      { id: "audit-initial-3", action: "Defensive guardrails enabled", detail: "Advisory-only responses, source grounding, secret redaction, and audit recording are enabled.", kind: "shield", createdAt: new Date(Date.now() - 60 * 60000) },
    ]).onConflictDoNothing();
  })().catch(error => { initialization = undefined; throw error; });
  return initialization;
}
export async function audit(action: string, detail: string, kind: string, validated = true) {
  await db.insert(auditEvents).values({ id: crypto.randomUUID(), action, detail, kind, validated });
}
