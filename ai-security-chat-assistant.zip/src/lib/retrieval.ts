import { embed, similarity } from "@/lib/security";
type VectorSource = { id: string; title: string; content: string; embedding: number[] };
// The optional authenticated Python engine can be deployed independently.
// Local fallback uses the exact same embedding space, so stored vectors remain compatible.
export async function retrieveSources<T extends VectorSource>(query: string, documents: T[]): Promise<(T & { score: number })[]> {
  if (process.env.SECURITY_ENGINE_URL && process.env.SECURITY_ENGINE_TOKEN) {
    try {
      const response = await fetch(`${process.env.SECURITY_ENGINE_URL.replace(/\/$/, "")}/retrieve`, {
        method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${process.env.SECURITY_ENGINE_TOKEN}` },
        body: JSON.stringify({ query, documents: documents.map(d => ({ id: d.id, embedding: d.embedding })), limit: 3 }), signal: AbortSignal.timeout(4000),
      });
      if (!response.ok) throw new Error("Python retrieval unavailable");
      const payload = await response.json();
      if (!Array.isArray(payload.results)) throw new Error("Invalid retrieval response");
      const results: (T & { score: number })[] = [];
      for (const match of payload.results.slice(0, 3)) {
        const source = documents.find(d => d.id === match.id);
        if (!source || typeof match.score !== "number" || !Number.isFinite(match.score) || match.score < 0 || match.score > 1.001) throw new Error("Invalid retrieval match");
        results.push({ ...source, score: match.score });
      }
      return results;
    } catch { console.warn("Python retrieval unavailable; using compatible local vector retrieval."); }
  }
  const vector = embed(query);
  return documents.map(source => ({ ...source, score: similarity(vector, source.embedding) })).sort((a, b) => b.score - a.score).filter(s => s.score > 0.09).slice(0, 3);
}
