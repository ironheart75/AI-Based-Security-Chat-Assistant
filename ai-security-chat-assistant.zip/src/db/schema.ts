import { pgTable, text, timestamp, integer, jsonb, boolean } from "drizzle-orm/pg-core";

export const alerts = pgTable("security_alerts", {
  id: text("id").primaryKey(), title: text("title").notNull(),
  severity: text("severity").notNull(), source: text("source").notNull(),
  host: text("host").notNull(), description: text("description").notNull(),
  log: text("log").notNull(), status: text("status").notNull().default("Open"),
  occurrences: integer("occurrences").notNull().default(1),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});
export const sources = pgTable("knowledge_sources", {
  id: text("id").primaryKey(), title: text("title").notNull(),
  category: text("category").notNull(), content: text("content").notNull(),
  embedding: jsonb("embedding").$type<number[]>().notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});
export const investigations = pgTable("investigations", {
  id: text("id").primaryKey(), title: text("title").notNull(),
  messages: jsonb("messages").$type<ChatMessage[]>().notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});
export const auditEvents = pgTable("audit_events", {
  id: text("id").primaryKey(), action: text("action").notNull(),
  detail: text("detail").notNull(), kind: text("kind").notNull(),
  validated: boolean("validated").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});
export type Citation = { id: string; title: string; excerpt: string; score: number };
export type ChatMessage = { role: "user" | "assistant"; content: string; citations?: Citation[]; mode?: string };
