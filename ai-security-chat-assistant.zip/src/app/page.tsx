import SecurityWorkspace from "@/components/security-workspace";
export default function HomePage() { return <SecurityWorkspace />; }
