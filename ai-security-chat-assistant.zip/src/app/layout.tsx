import type { Metadata } from "next";
import type { ReactNode } from "react";
import "@fontsource-variable/inter";
import "./globals.css";
import "./refinements.css";

export const metadata: Metadata = {
  title: "Sentinel — Security, with clarity",
  description: "Your defensive security copilot. Investigate alerts, understand logs, and find answers grounded in your knowledge.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-slate-100 text-slate-900 antialiased">{children}</body>
    </html>
  );
}
