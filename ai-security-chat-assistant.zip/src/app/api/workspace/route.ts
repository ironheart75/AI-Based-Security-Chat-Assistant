import { NextResponse } from "next/server";
import { db } from "@/db";
import { alerts, sources, investigations, auditEvents } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { initializeWorkspace, audit } from "@/lib/store";
import { embed } from "@/lib/security";
export const dynamic = "force-dynamic";
export async function GET() {
  try {
    await initializeWorkspace();
    const [alertRows, sourceRows, sessions, events] = await Promise.all([
      db.select().from(alerts).orderBy(desc(alerts.createdAt)),
      db.select({ id: sources.id, title: sources.title, category: sources.category, content: sources.content, createdAt: sources.createdAt }).from(sources).orderBy(desc(sources.createdAt)),
      db.select().from(investigations).orderBy(desc(investigations.createdAt)),
      db.select().from(auditEvents).orderBy(desc(auditEvents.createdAt)).limit(200),
    ]);
    return NextResponse.json({ alerts: alertRows, sources: sourceRows, investigations: sessions, events, mode: process.env.OPENAI_API_KEY && process.env.APPROVED_LLM_MODEL ? "Approved LLM" : "Local retrieval" });
  } catch (error) { console.error("Workspace load failed", error); return NextResponse.json({ error: "Workspace could not be loaded. Please try again." }, { status: 500 }); }
}
export async function POST(request: Request) {
  try {
    await initializeWorkspace();
    const body = await request.json().catch(() => null);
    if (!body || typeof body !== "object" || Array.isArray(body)) return NextResponse.json({ error: "A valid JSON request body is required." }, { status: 400 });
    if (body.action === "addSource") {
      if (typeof body.title !== "string" || typeof body.content !== "string" || body.title.trim().length < 3 || body.title.length > 160 || body.content.trim().length < 50 || body.content.length > 40000) return NextResponse.json({ error: "Enter a title (3–160 characters) and source content (50–40,000 characters)." }, { status: 400 });
      const categories = ["Playbook", "Runbook", "Documentation", "Policy"];
      const source = { id: crypto.randomUUID(), title: body.title.trim(), content: body.content.trim(), category: categories.includes(body.category) ? body.category : "Documentation", embedding: embed(body.title + " " + body.content) };
      await db.transaction(async tx => {
        await tx.insert(sources).values(source);
        await tx.insert(auditEvents).values({ id: crypto.randomUUID(), action: "Knowledge source added", detail: `${source.title} was indexed for grounded retrieval.`, kind: "source" });
      });
      return NextResponse.json({ success: true });
    }
    if (body.action === "resolveAlert" && typeof body.id === "string") {
      const [updated] = await db.update(alerts).set({ status: "Resolved" }).where(eq(alerts.id, body.id)).returning();
      if (!updated) return NextResponse.json({ error: "Alert not found." }, { status: 404 });
      await audit("Alert marked resolved", `${updated.id}: ${updated.title}. Analyst-reviewed; no containment action was executed.`, "alert");
      return NextResponse.json({ success: true });
    }
    return NextResponse.json({ error: "Unknown action." }, { status: 400 });
  } catch (error) { console.error("Workspace action failed", error); return NextResponse.json({ error: "Could not save this change. Please try again." }, { status: 500 }); }
}
